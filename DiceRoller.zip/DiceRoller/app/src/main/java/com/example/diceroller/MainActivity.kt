package com.example.diceroller

import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.diceroller.ui.theme.DiceRollerTheme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DiceRollerTheme {
                DiceRollerApp()
            }
        }
    }
}

@Composable
fun DiceRollerApp() {
    val context = LocalContext.current
    var diceNumber1 by remember { mutableIntStateOf(1) }
    var diceNumber2 by remember { mutableIntStateOf(1) }

    var rollHistory by remember { mutableStateOf(listOf<String>()) }

    var rotated by remember { mutableStateOf(false) }
    val rotationAngle by animateFloatAsState(
        targetValue = if (rotated) 360f else 0f,
        animationSpec = tween(durationMillis = 400),
        finishedListener = { rotated = false }
    )

    val diceImage1 = when (diceNumber1) {
        1 -> R.drawable.dice_1
        2 -> R.drawable.dice_2
        3 -> R.drawable.dice_3
        4 -> R.drawable.dice_4
        5 -> R.drawable.dice_5
        else -> R.drawable.dice_6
    }

    val diceImage2 = when (diceNumber2) {
        1 -> R.drawable.dice_1
        2 -> R.drawable.dice_2
        3 -> R.drawable.dice_3
        4 -> R.drawable.dice_4
        5 -> R.drawable.dice_5
        else -> R.drawable.dice_6
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = diceImage1),
                contentDescription = diceNumber1.toString(),
                modifier = Modifier
                    .size(130.dp)
                    .rotate(rotationAngle)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Image(
                painter = painterResource(id = diceImage2),
                contentDescription = diceNumber2.toString(),
                modifier = Modifier
                    .size(130.dp)
                    .rotate(rotationAngle)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Tombol Kocok Dadu
        Button(
            onClick = {
                // Memutar suara saat tombol diklik
                val mediaPlayer = MediaPlayer.create(context, R.raw.dice_sound)
                mediaPlayer?.start()

                // Menghentikan dan merilis suara secara otomatis setelah 400 milidetik (pas dengan durasi animasi)
                Handler(Looper.getMainLooper()).postDelayed({
                    try {
                        if (mediaPlayer?.isPlaying == true) {
                            mediaPlayer.stop()
                        }
                        mediaPlayer?.release()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, 400) // Sesuaikan angka ini (dalam milidetik) jika ingin suara lebih panjang/pendek

                val newRoll1 = Random.nextInt(1, 7)
                val newRoll2 = Random.nextInt(1, 7)

                diceNumber1 = newRoll1
                diceNumber2 = newRoll2
                rotated = true

                val historyText = "Dadu 1: $newRoll1, Dadu 2: $newRoll2"
                rollHistory = listOf(historyText) + rollHistory.take(3)
            }
        ) {
            Text("Kocok Dadu")
        }

        Spacer(modifier = Modifier.height(32.dp))

        Text(
            text = "Riwayat Kocokan Sebelumnya:",
            style = MaterialTheme.typography.titleMedium
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (rollHistory.isEmpty()) {
            Text(text = "Belum ada riwayat kocokan", fontSize = 14.sp, color = MaterialTheme.colorScheme.secondary)
        } else {
            rollHistory.forEach { item ->
                Text(text = item, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp))
            }
        }
    }
}